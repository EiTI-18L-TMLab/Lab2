Lab 2
